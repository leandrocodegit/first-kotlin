package error;

public final class NonExistentClass {
}